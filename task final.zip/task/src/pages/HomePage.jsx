
    import React from 'react';
    import { Link } from 'react-router-dom';
    import { Button } from '@/components/ui/button';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
    import { motion } from 'framer-motion';
    import { PlusSquare, ListChecks, CheckCircle, Zap, ArrowRight, AlertTriangle, Info, Activity } from 'lucide-react';
    import { useTasks } from '@/context/TaskContext';
    import { useAuth } from '@/context/AuthContext';
    import { format, formatDistanceToNow } from 'date-fns';

    const HomePage = () => {
      const { tasks } = useTasks();
      const { user } = useAuth();
      
      const upcomingTasks = tasks
        .filter(task => task.status !== 'Completed' && new Date(task.dueDate) >= new Date())
        .sort((a, b) => new Date(a.dueDate) - new Date(b.dueDate))
        .slice(0, 3);

      const completedTasksCount = tasks.filter(task => task.status === 'Completed').length;
      const pendingTasksCount = tasks.filter(task => task.status !== 'Completed').length;
      const highPriorityTasks = tasks.filter(task => task.priority === 'High' && task.status !== 'Completed').length;


      const containerVariants = {
        hidden: { opacity: 0 },
        visible: {
          opacity: 1,
          transition: {
            staggerChildren: 0.1,
            delayChildren: 0.2,
          },
        },
      };

      const itemVariants = {
        hidden: { y: 20, opacity: 0 },
        visible: {
          y: 0,
          opacity: 1,
          transition: {
            type: 'spring',
            stiffness: 100,
            damping: 12
          },
        },
      };
      
      const getPriorityIcon = (priority) => {
        switch (priority) {
          case 'High': return <AlertTriangle className="w-4 h-4 text-red-500" />;
          case 'Medium': return <Activity className="w-4 h-4 text-yellow-500" />;
          case 'Low': return <Info className="w-4 h-4 text-green-500" />;
          default: return null;
        }
      };

      return (
        <motion.div 
          className="space-y-12"
          initial="hidden"
          animate="visible"
          variants={containerVariants}
        >
          <motion.section 
            className="text-center py-16 bg-gradient-to-br from-primary/70 via-accent/60 to-blue-500/60 dark:from-primary/40 dark:via-accent/30 dark:to-blue-500/30 rounded-xl shadow-2xl overflow-hidden"
            variants={itemVariants}
          >
            <div className="relative bg-background/30 dark:bg-card/40 backdrop-blur-md py-10 px-6 rounded-lg inline-block max-w-3xl mx-auto">
              <Zap className="absolute -top-5 -left-5 w-16 h-16 text-yellow-400 opacity-60 transform rotate-12" />
              <Zap className="absolute -bottom-5 -right-5 w-16 h-16 text-blue-400 opacity-60 transform -rotate-12" />
              <h1 className="text-4xl sm:text-5xl font-extrabold text-foreground mb-5">
                Welcome {user ? <span className="text-primary">{user.name}</span> : ''} to <br/> <span className="block text-5xl sm:text-6xl gradient-text">TaskMaster</span>
              </h1>
              <p className="text-lg sm:text-xl text-foreground/80 dark:text-foreground/70 mb-8 max-w-xl mx-auto">
                Organize your work, manage deadlines, and boost your productivity. Let's get things done!
              </p>
              <motion.div className="space-y-3 sm:space-y-0 sm:space-x-4 flex flex-col sm:flex-row justify-center items-center" variants={itemVariants}>
                <Button size="lg" asChild className="bg-primary hover:bg-primary/90 text-primary-foreground font-semibold py-3 px-6 rounded-lg shadow-lg transform hover:scale-105 transition-transform duration-300 text-md w-full sm:w-auto">
                  <Link to={user ? "/create-task" : "/register"}>
                    {user ? "Add New Task" : "Get Started"} <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                </Button>
                <Button variant="outline" size="lg" asChild className="border-primary text-primary hover:bg-primary/10 font-semibold py-3 px-6 rounded-lg shadow-lg transform hover:scale-105 transition-transform duration-300 text-md w-full sm:w-auto">
                  <Link to="/tasks">View All Tasks</Link>
                </Button>
              </motion.div>
            </div>
          </motion.section>

          <motion.section variants={itemVariants} className="grid md:grid-cols-3 gap-4 sm:gap-6">
            {[
              { title: "Pending Tasks", count: pendingTasksCount, icon: <ListChecks className="w-8 h-8 text-blue-500" />, color: "blue" },
              { title: "Completed Tasks", count: completedTasksCount, icon: <CheckCircle className="w-8 h-8 text-green-500" />, color: "green" },
              { title: "High Priority", count: highPriorityTasks, icon: <AlertTriangle className="w-8 h-8 text-red-500" />, color: "red" },
            ].map((stat, index) => (
              <motion.div key={index} variants={itemVariants}>
                 <Card className={`professional-card border-l-4 border-${stat.color}-500 hover:shadow-xl`}>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium text-foreground/80">{stat.title}</CardTitle>
                        {stat.icon}
                    </CardHeader>
                    <CardContent>
                        <div className={`text-3xl font-bold text-${stat.color}-500`}>{stat.count}</div>
                        <p className="text-xs text-muted-foreground">
                          {stat.title === "Pending Tasks" ? "Tasks to be completed" : stat.title === "Completed Tasks" ? "Tasks finished" : "Urgent tasks"}
                        </p>
                    </CardContent>
                 </Card>
              </motion.div>
            ))}
          </motion.section>


          {upcomingTasks.length > 0 && (
            <motion.section variants={itemVariants}>
              <h2 className="text-3xl sm:text-4xl font-bold mb-8 text-center text-foreground">Your Next <span className="gradient-text">Important Tasks</span></h2>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-7">
                {upcomingTasks.map(task => (
                  <motion.div key={task.id} variants={itemVariants}>
                    <Card className="h-full hover:shadow-xl transition-shadow duration-300 overflow-hidden group professional-card flex flex-col">
                      <CardHeader>
                        <div className="flex justify-between items-start">
                          <CardTitle className="text-xl sm:text-2xl truncate">{task.title}</CardTitle>
                          {getPriorityIcon(task.priority)}
                        </div>
                        <CardDescription className="text-xs sm:text-sm text-muted-foreground">
                          Due: {format(new Date(task.dueDate), 'PPP')} ({formatDistanceToNow(new Date(task.dueDate), { addSuffix: true })})
                        </CardDescription>
                        {task.project && <span className="text-xs bg-secondary text-secondary-foreground px-2 py-0.5 rounded-full w-fit">{task.project}</span>}
                      </CardHeader>
                      <CardContent className="flex-grow">
                        <p className="text-foreground/80 dark:text-foreground/70 line-clamp-3 text-sm sm:text-base">{task.description}</p>
                      </CardContent>
                      <CardFooter>
                        <Button asChild className="w-full bg-primary hover:bg-primary/90 text-primary-foreground text-base sm:text-lg py-2.5">
                          <Link to={`/task/${task.id}`}>View Details</Link>
                        </Button>
                      </CardFooter>
                    </Card>
                  </motion.div>
                ))}
              </div>
               {tasks.filter(task => task.status !== 'Completed').length > 3 && (
                 <motion.div className="text-center mt-10" variants={itemVariants}>
                    <Button size="lg" variant="outline" asChild className="border-primary text-primary hover:bg-primary/10 font-semibold py-3 px-6 rounded-lg shadow-md transform hover:scale-105 transition-transform duration-300 text-base">
                        <Link to="/tasks">View All Tasks <ArrowRight className="ml-2 h-5 w-5" /></Link>
                    </Button>
                 </motion.div>
                )}
            </motion.section>
          )}
          
          <motion.section variants={itemVariants} className="text-center py-10">
             <img  class="w-full max-w-2xl sm:max-w-3xl mx-auto rounded-xl shadow-xl border-2 border-border" alt="Illustration of a productive workspace with task lists and charts" src="https://images.unsplash.com/photo-1665938225843-f4126f08d303" />
          </motion.section>
        </motion.div>
      );
    };

    export default HomePage;
  